<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('groups', function (Blueprint $table) {
            $table->string('field_number')->nullable()->change();
        });
        Schema::table('matches', function (Blueprint $table) {
            $table->string('field_number')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('groups', function (Blueprint $table) {
            $table->integer('field_number')->nullable()->change();
        });
        Schema::table('matches', function (Blueprint $table) {
            $table->integer('field_number')->nullable()->change();
        });
    }
};
