<?php

use App\Models\Category;
use App\Models\Group;
use App\Models\Team;
use App\Models\GroupTeam;
use App\Models\TournamentMatch;
use Livewire\Attributes\Computed;
use Livewire\Component;

new class extends Component
{
    public $gameType;
    public $categorySlug;
    public $category;

    // Late Team Modal State
    public bool $showAddLateTeamModal = false;
    public ?int $selectedLateTeamId = null;
    public ?int $selectedTargetGroupId = null;

    // Create Group Modal State
    public bool $showCreateGroupModal = false;
    public string $newGroupName = '';
    public string $newGroupLetter = '';
    public ?string $newGroupField = null;

    // Playoff Modal State
    public bool $showPlayoffModal = false;
    public ?int $playoffGroupId = null;
    public ?int $playoffTeam1Id = null;
    public ?int $playoffTeam2Id = null;
    public ?string $playoffFieldNumber = null;
    
    public function mount($gameType, $categorySlug)
    {
        $this->gameType = $gameType;
        $this->categorySlug = $categorySlug;
        $this->category = Category::where('slug', $categorySlug)->firstOrFail();
    }

    #[Computed]
    public function groups()
    {
        return Group::with(['groupTeams.team', 'matches'])
            ->where('category_id', $this->category->id)
            ->where('game_type', $this->gameType)
            ->orderBy('group_name')
            ->get();
    }

    #[Computed]
    public function unassignedTeams()
    {
        $assignedTeamIds = GroupTeam::whereHas('group', function($q) {
            $q->where('category_id', $this->category->id)
              ->where('game_type', $this->gameType);
        })->pluck('team_id');

        return Team::where('category_id', $this->category->id)
            ->where('game_type', $this->gameType)
            ->whereNotIn('id', $assignedTeamIds)
            ->orderBy('team_name')
            ->get();
    }

    public function assignField(int $groupId, ?string $fieldNumber)
    {
        $group = Group::where('id', $groupId)->where('category_id', $this->category->id)->firstOrFail();
        $group->field_number = empty($fieldNumber) ? null : $fieldNumber;
        $group->save();

        // Also update all scheduled (unplayed) matches for this group immediately
        TournamentMatch::where('group_id', $groupId)
            ->where('status', 'scheduled')
            ->update(['field_number' => $group->field_number]);
    }

    public function openCreateGroupModal(): void
    {
        $existingLetters = $this->groups->pluck('group_letter')->map(fn($l) => strtoupper(trim($l)))->toArray();
        if ($this->gameType === 'obstacle') {
            $nextNum = $this->groups->count() + 1;
            $this->newGroupLetter = (string)$nextNum;
            $this->newGroupName = 'Course ' . $nextNum;
            $this->newGroupField = 'Course ' . $nextNum;
        } else {
            $nextLetter = 'A';
            foreach (range('A', 'Z') as $letter) {
                if (!in_array($letter, $existingLetters)) {
                    $nextLetter = $letter;
                    break;
                }
            }
            $this->newGroupLetter = $nextLetter;
            $this->newGroupName = 'Kumpulan ' . $nextLetter;
            $this->newGroupField = $this->gameType === 'sky_soccer' ? 'Arena Sky Soccer' : null;
        }
        $this->showCreateGroupModal = true;
    }

    public function closeCreateGroupModal(): void
    {
        $this->showCreateGroupModal = false;
        $this->newGroupName = '';
        $this->newGroupLetter = '';
        $this->newGroupField = null;
    }

    public function createGroup(): void
    {
        $this->validate([
            'newGroupName' => 'required|string|max:50',
            'newGroupLetter' => 'required|string|max:10',
        ], [
            'newGroupName.required' => 'Sila masukkan nama kumpulan.',
            'newGroupLetter.required' => 'Sila masukkan huruf / kod kumpulan.',
        ]);

        Group::create([
            'category_id' => $this->category->id,
            'game_type'   => $this->gameType,
            'group_name'  => trim($this->newGroupName),
            'group_letter'=> strtoupper(trim($this->newGroupLetter)),
            'field_number'=> $this->newGroupField ?: null,
        ]);

        $createdName = trim($this->newGroupName);
        $this->closeCreateGroupModal();
        $this->js("alert('Kumpulan {$createdName} berjaya dicipta! Anda kini boleh memasukkan pasukan ke dalamnya.');");
    }

    public function deleteSingleGroup(int $groupId): void
    {
        $group = Group::where('id', $groupId)->where('category_id', $this->category->id)->firstOrFail();

        // Check if any match in this group is completed or in progress
        $hasActiveMatches = TournamentMatch::where('group_id', $group->id)
            ->whereIn('status', ['completed', 'in_progress'])
            ->exists();

        if ($hasActiveMatches) {
            $this->js("alert('Kumpulan {$group->group_name} tidak boleh dipadam kerana sudah mempunyai perlawanan yang berjalan atau selesai!');");
            return;
        }

        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            TournamentMatch::where('group_id', $group->id)->delete();
            GroupTeam::where('group_id', $group->id)->delete();
            $group->delete();
            \Illuminate\Support\Facades\DB::commit();
            $this->js("alert('Kumpulan {$group->group_name} berjaya dipadam.');");
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            $this->js("alert('Ralat: {$e->getMessage()}');");
        }
    }

    public function generateSingleGroupFixtures(int $groupId): void
    {
        $group = Group::where('id', $groupId)->where('category_id', $this->category->id)->firstOrFail();
        $teams = $group->groupTeams()->pluck('team_id')->toArray();
        $teamCount = count($teams);

        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            if ($this->gameType === 'obstacle') {
                if ($teamCount < 1) {
                    $this->js("alert('Sila masukkan sekurang-kurangnya 1 pasukan.');");
                    return;
                }
                TournamentMatch::where('group_id', $group->id)->where('status', 'scheduled')->delete();
                foreach ($teams as $index => $teamId) {
                    TournamentMatch::create([
                        'category_id' => $this->category->id,
                        'group_id' => $group->id,
                        'stage' => 'group',
                        'round_name' => 'Larian ' . ($index + 1),
                        'home_team_id' => $teamId,
                        'away_team_id' => null,
                        'field_number' => $group->field_number ?? 'Course 1',
                        'status' => 'scheduled'
                    ]);
                }
            } else {
                if ($teamCount < 2) {
                    $this->js("alert('Sila masukkan sekurang-kurangnya 2 pasukan ke dalam kumpulan ini untuk menjana perlawanan.');");
                    return;
                }
                TournamentMatch::where('group_id', $group->id)->where('status', 'scheduled')->delete();

                if ($teamCount % 2 != 0) {
                    $teams[] = null;
                    $teamCount++;
                }

                $rounds = $teamCount - 1;
                $matchesPerRound = $teamCount / 2;

                for ($round = 0; $round < $rounds; $round++) {
                    for ($match = 0; $match < $matchesPerRound; $match++) {
                        $home = $teams[$match];
                        $away = $teams[$teamCount - 1 - $match];

                        if ($home !== null && $away !== null) {
                            TournamentMatch::create([
                                'category_id' => $this->category->id,
                                'group_id' => $group->id,
                                'stage' => 'group',
                                'round_name' => 'Kumpulan ' . $group->group_letter . ' - P' . ($round + 1),
                                'home_team_id' => $home,
                                'away_team_id' => $away,
                                'field_number' => $group->field_number ?: ($this->gameType === 'sky_soccer' ? 'Arena Sky Soccer' : null),
                                'status' => 'scheduled'
                            ]);
                        }
                    }

                    $temp = $teams[$teamCount - 1];
                    for ($i = $teamCount - 1; $i > 1; $i--) {
                        $teams[$i] = $teams[$i - 1];
                    }
                    $teams[1] = $temp;
                }
            }
            \Illuminate\Support\Facades\DB::commit();
            $this->js("alert('Jadual perlawanan bagi {$group->group_name} berjaya dijana!');");
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            $this->js("alert('Ralat: {$e->getMessage()}');");
        }
    }

    public function openAddLateTeamModal(?int $groupId = null): void
    {
        $this->selectedTargetGroupId = $groupId;
        $this->selectedLateTeamId = null;
        $this->showAddLateTeamModal = true;
    }

    public function closeAddLateTeamModal(): void
    {
        $this->showAddLateTeamModal = false;
        $this->selectedLateTeamId = null;
        $this->selectedTargetGroupId = null;
    }

    public function addLateTeam(): void
    {
        $this->validate([
            'selectedLateTeamId' => 'required|exists:teams,id',
            'selectedTargetGroupId' => 'required|exists:groups,id',
        ], [
            'selectedLateTeamId.required' => 'Sila pilih pasukan yang hendak dimasukkan.',
            'selectedTargetGroupId.required' => 'Sila pilih kumpulan sasaran.',
        ]);

        $team = Team::findOrFail($this->selectedLateTeamId);
        $group = Group::where('id', $this->selectedTargetGroupId)
            ->where('category_id', $this->category->id)
            ->firstOrFail();

        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            // 1. Mark team status as checked_in
            if ($team->status !== 'checked_in') {
                $team->update([
                    'status' => 'checked_in',
                    'checked_in_at' => now(),
                ]);
            }

            // 2. Add team to GroupTeam
            GroupTeam::firstOrCreate([
                'group_id' => $group->id,
                'team_id' => $team->id,
            ]);

            // 3. If fixtures already exist for this group, generate additional matches
            $existingMatchesCount = TournamentMatch::where('group_id', $group->id)->count();

            if ($existingMatchesCount > 0) {
                if ($this->gameType === 'obstacle') {
                    // Append single time trial run slot
                    TournamentMatch::create([
                        'category_id' => $this->category->id,
                        'group_id' => $group->id,
                        'stage' => 'group',
                        'round_name' => 'Larian ' . ($existingMatchesCount + 1),
                        'home_team_id' => $team->id,
                        'away_team_id' => null,
                        'field_number' => $group->field_number ?? 'Course 1',
                        'status' => 'scheduled'
                    ]);
                } else {
                    // Round-robin: create match against all other teams in the group
                    $otherTeamIds = $group->groupTeams()
                        ->where('team_id', '!=', $team->id)
                        ->pluck('team_id');

                    $extraMatchCount = 0;
                    foreach ($otherTeamIds as $otherTeamId) {
                        $alreadyMatched = TournamentMatch::where('group_id', $group->id)
                            ->where(function($q) use ($team, $otherTeamId) {
                                $q->where(function($q2) use ($team, $otherTeamId) {
                                    $q2->where('home_team_id', $team->id)->where('away_team_id', $otherTeamId);
                                })->orWhere(function($q2) use ($team, $otherTeamId) {
                                    $q2->where('home_team_id', $otherTeamId)->where('away_team_id', $team->id);
                                });
                            })->exists();

                        if (!$alreadyMatched) {
                            $extraMatchCount++;
                            TournamentMatch::create([
                                'category_id' => $this->category->id,
                                'group_id' => $group->id,
                                'stage' => 'group',
                                'round_name' => 'Kumpulan ' . $group->group_letter . ' - Tambahan ' . $extraMatchCount,
                                'home_team_id' => $team->id,
                                'away_team_id' => $otherTeamId,
                                'field_number' => $group->field_number,
                                'status' => 'scheduled'
                            ]);
                        }
                    }
                }
            } else {
                // If group had 0 matches, but now has >= 2 teams (or obstacle >= 1) and other groups have fixtures:
                $hasCategoryFixtures = TournamentMatch::where('category_id', $this->category->id)
                    ->whereHas('group', fn($q) => $q->where('game_type', $this->gameType))
                    ->where('stage', 'group')
                    ->exists();

                if ($hasCategoryFixtures) {
                    $teamCount = $group->groupTeams()->count();
                    if (($this->gameType === 'obstacle' && $teamCount >= 1) || ($this->gameType !== 'obstacle' && $teamCount >= 2)) {
                        $this->generateSingleGroupFixtures($group->id);
                    }
                }
            }

            \Illuminate\Support\Facades\DB::commit();
            $this->closeAddLateTeamModal();
            $this->js("alert('Pasukan {$team->team_name} berjaya dimasukkan ke {$group->group_name} dan jadual perlawanan telah dikemaskini!');");
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            $this->js("alert('Ralat: {$e->getMessage()}');");
        }
    }

    public function removeTeamFromGroup(int $groupId, int $teamId): void
    {
        $group = Group::where('id', $groupId)->where('category_id', $this->category->id)->firstOrFail();
        $team = Team::findOrFail($teamId);

        // Check if this team has completed any match
        $hasCompletedMatches = TournamentMatch::where('group_id', $group->id)
            ->where(function($q) use ($teamId) {
                $q->where('home_team_id', $teamId)->orWhere('away_team_id', $teamId);
            })
            ->whereIn('status', ['completed', 'in_progress'])
            ->exists();

        if ($hasCompletedMatches) {
            $this->js("alert('Pasukan {$team->team_name} tidak boleh dikeluarkan kerana telah mempunyai rekod perlawanan yang selesai atau sedang berlangsung!');");
            return;
        }

        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            // Delete scheduled matches for this team in this group
            TournamentMatch::where('group_id', $group->id)
                ->where(function($q) use ($teamId) {
                    $q->where('home_team_id', $teamId)->orWhere('away_team_id', $teamId);
                })
                ->where('status', 'scheduled')
                ->delete();

            // Delete group team record
            GroupTeam::where('group_id', $group->id)->where('team_id', $teamId)->delete();

            \Illuminate\Support\Facades\DB::commit();
            $this->js("alert('Pasukan {$team->team_name} telah dikeluarkan daripada {$group->group_name}.');");
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            $this->js("alert('Ralat: {$e->getMessage()}');");
        }
    }

    public function generateFixtures()
    {
        $groups = $this->groups;
        
        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            TournamentMatch::where('category_id', $this->category->id)
                ->whereHas('group', function($q) {
                    $q->where('game_type', $this->gameType);
                })
                ->where('stage', 'group')
                ->delete();

            if ($this->gameType === 'obstacle') {
                // For obstacle, it's a time trial (solo run)
                foreach ($groups as $group) {
                    $teams = $group->groupTeams()->pluck('team_id')->toArray();
                    foreach ($teams as $index => $teamId) {
                        TournamentMatch::create([
                            'category_id' => $this->category->id,
                            'group_id' => $group->id,
                            'stage' => 'group',
                            'round_name' => 'Larian ' . ($index + 1),
                            'home_team_id' => $teamId,
                            'away_team_id' => null, // No opponent
                            'field_number' => $group->field_number ?? 'Course 1',
                            'status' => 'scheduled'
                        ]);
                    }
                }
            } elseif ($this->gameType === 'sky_soccer') {
                // Sky Soccer: All groups share 'Arena Sky Soccer'.
                // Interleave matches round-by-round across groups so teams have rest periods!
                $roundMatches = [];
                foreach ($groups as $group) {
                    $teams = $group->groupTeams()->pluck('team_id')->toArray();
                    $teamCount = count($teams);
                    if ($teamCount < 2) continue;

                    if ($teamCount % 2 != 0) {
                        $teams[] = null;
                        $teamCount++;
                    }

                    $rounds = $teamCount - 1;
                    $matchesPerRound = $teamCount / 2;

                    for ($round = 0; $round < $rounds; $round++) {
                        for ($match = 0; $match < $matchesPerRound; $match++) {
                            $home = $teams[$match];
                            $away = $teams[$teamCount - 1 - $match];

                            if ($home !== null && $away !== null) {
                                $roundMatches[$round][] = [
                                    'category_id' => $this->category->id,
                                    'group_id' => $group->id,
                                    'stage' => 'group',
                                    'round_name' => 'Kumpulan ' . $group->group_letter . ' - P' . ($round + 1),
                                    'home_team_id' => $home,
                                    'away_team_id' => $away,
                                    'field_number' => $group->field_number ?: 'Arena Sky Soccer',
                                    'status' => 'scheduled'
                                ];
                            }
                        }

                        $temp = $teams[$teamCount - 1];
                        for ($i = $teamCount - 1; $i > 1; $i--) {
                            $teams[$i] = $teams[$i - 1];
                        }
                        $teams[1] = $temp;
                    }
                }

                // Insert interleaved by round across all groups (P1: Grp A, Grp B... P2: Grp A, Grp B...)
                ksort($roundMatches);
                $baseTime = now()->startOfDay()->addHours(8);
                $timeIndex = 0;
                foreach ($roundMatches as $roundIndex => $matchesInRound) {
                    foreach ($matchesInRound as $m) {
                        $m['scheduled_time'] = (clone $baseTime)->addMinutes($timeIndex * 5);
                        TournamentMatch::create($m);
                        $timeIndex++;
                    }
                }
            } else {
                // Round Robin for Isobot Soccer
                foreach ($groups as $group) {
                    $teams = $group->groupTeams()->pluck('team_id')->toArray();
                    $teamCount = count($teams);
                    if ($teamCount < 2) continue;

                    if ($teamCount % 2 != 0) {
                        $teams[] = null;
                        $teamCount++;
                    }

                    $rounds = $teamCount - 1;
                    $matchesPerRound = $teamCount / 2;

                    for ($round = 0; $round < $rounds; $round++) {
                        for ($match = 0; $match < $matchesPerRound; $match++) {
                            $home = $teams[$match];
                            $away = $teams[$teamCount - 1 - $match];

                            if ($home !== null && $away !== null) {
                                TournamentMatch::create([
                                    'category_id' => $this->category->id,
                                    'group_id' => $group->id,
                                    'stage' => 'group',
                                    'round_name' => 'Kumpulan ' . $group->group_letter . ' - P' . ($round + 1),
                                    'home_team_id' => $home,
                                    'away_team_id' => $away,
                                    'field_number' => $group->field_number,
                                    'status' => 'scheduled'
                                ]);
                            }
                        }

                        $temp = $teams[$teamCount - 1];
                        for ($i = $teamCount - 1; $i > 1; $i--) {
                            $teams[$i] = $teams[$i - 1];
                        }
                        $teams[1] = $temp;
                    }
                }
            }
            \Illuminate\Support\Facades\DB::commit();
            session()->flash('success', 'Senarai giliran perlawanan/larian berjaya dijana!');
            return redirect()->route('admin.matches.index');
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            $this->js("alert('Ralat: {$e->getMessage()}');");
        }
    }

    public function deleteFixtures()
    {
        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            TournamentMatch::where('category_id', $this->category->id)
                ->whereHas('group', function($q) {
                    $q->where('game_type', $this->gameType);
                })
                ->where('stage', 'group')
                ->delete();

            $groupIds = $this->groups->pluck('id');
            GroupTeam::whereIn('group_id', $groupIds)->update([
                'played' => 0,
                'won' => 0,
                'drawn' => 0,
                'lost' => 0,
                'goals_for' => 0,
                'goals_against' => 0,
                'goal_difference' => 0,
                'points' => 0,
            ]);

            \Illuminate\Support\Facades\DB::commit();
            $this->js("alert('Jadual perlawanan dan statistik kumpulan telah berjaya dipadam.');");
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            $this->js("alert('Ralat: {$e->getMessage()}');");
        }
    }

    public function getTiedPairs(Group $group): array
    {
        if ($group->game_type === 'obstacle') return [];
        $standings = $group->getStandings();
        $tied = [];
        $count = count($standings);
        for ($i = 0; $i < $count - 1; $i++) {
            $a = $standings[$i];
            $b = $standings[$i + 1];
            if ($a->played > 0 && $b->played > 0 &&
                $a->points === $b->points &&
                $a->won === $b->won &&
                $a->goals_for === $b->goals_for &&
                $a->goal_difference === $b->goal_difference &&
                $a->goals_against === $b->goals_against) {

                $hasCompletedPlayoff = TournamentMatch::where('group_id', $group->id)
                    ->where('status', 'completed')
                    ->where(function($q) {
                        $q->where('round_name', 'like', '%Play-off%')
                          ->orWhere('round_name', 'like', '%Penentuan%');
                    })
                    ->where(function($q) use ($a, $b) {
                        $q->where(function($sub) use ($a, $b) {
                            $sub->where('home_team_id', $a->team_id)->where('away_team_id', $b->team_id);
                        })->orWhere(function($sub) use ($a, $b) {
                            $sub->where('home_team_id', $b->team_id)->where('away_team_id', $a->team_id);
                        });
                    })
                    ->whereNotNull('winner_team_id')
                    ->exists();

                $hasManualPosition = ($a->position > 0 && $b->position > 0 && $a->position !== $b->position);

                $tied[] = [
                    'team1' => $a,
                    'team2' => $b,
                    'rank1' => $i + 1,
                    'rank2' => $i + 2,
                    'resolved' => ($hasCompletedPlayoff || $hasManualPosition),
                ];
            }
        }
        return $tied;
    }

    public function openPlayoffModal(int $groupId, ?int $t1 = null, ?int $t2 = null): void
    {
        $group = Group::where('id', $groupId)->where('category_id', $this->category->id)->firstOrFail();
        $this->playoffGroupId = $groupId;
        $this->playoffTeam1Id = $t1;
        $this->playoffTeam2Id = $t2;
        $this->playoffFieldNumber = $group->field_number ?? ($this->gameType === 'sky_soccer' ? 'Arena Sky Soccer' : '1');
        $this->showPlayoffModal = true;
    }

    public function closePlayoffModal(): void
    {
        $this->showPlayoffModal = false;
        $this->playoffGroupId = null;
        $this->playoffTeam1Id = null;
        $this->playoffTeam2Id = null;
        $this->playoffFieldNumber = null;
    }

    public function createPlayoffMatch(): void
    {
        $this->validate([
            'playoffGroupId' => 'required|exists:groups,id',
            'playoffTeam1Id' => 'required|exists:teams,id|different:playoffTeam2Id',
            'playoffTeam2Id' => 'required|exists:teams,id',
        ], [
            'playoffTeam1Id.required' => 'Sila pilih Pasukan 1.',
            'playoffTeam2Id.required' => 'Sila pilih Pasukan 2.',
            'playoffTeam1Id.different' => 'Pasukan 1 dan Pasukan 2 mestilah berbeza.',
        ]);

        $group = Group::where('id', $this->playoffGroupId)->where('category_id', $this->category->id)->firstOrFail();

        TournamentMatch::create([
            'category_id' => $this->category->id,
            'group_id' => $group->id,
            'stage' => 'group',
            'round_name' => 'Perlawanan Penentuan (Play-off)',
            'home_team_id' => $this->playoffTeam1Id,
            'away_team_id' => $this->playoffTeam2Id,
            'field_number' => $this->playoffFieldNumber ?: ($group->field_number ?? null),
            'status' => 'scheduled',
        ]);

        $team1 = Team::find($this->playoffTeam1Id);
        $team2 = Team::find($this->playoffTeam2Id);
        $t1Name = $team1 ? $team1->team_name : 'Pasukan 1';
        $t2Name = $team2 ? $team2->team_name : 'Pasukan 2';
        $fName = $this->playoffFieldNumber ? "Padang {$this->playoffFieldNumber}" : 'Padang ditetapkan';

        $this->closePlayoffModal();
        $this->js("alert('Perlawanan Penentuan ({$t1Name} vs {$t2Name}) berjaya dicipta untuk {$fName}! Pengadil boleh memasukkan keputusan di Field Dashboard.');");
    }

    public function swapTeamPosition(int $groupTeamId1, int $groupTeamId2): void
    {
        $gt1 = GroupTeam::where('id', $groupTeamId1)->firstOrFail();
        $gt2 = GroupTeam::where('id', $groupTeamId2)->firstOrFail();

        if ($gt1->group_id !== $gt2->group_id) return;

        $group = $gt1->group;
        $standings = $group->getStandings();

        // Initialize positions if not set
        $posMap = [];
        foreach ($standings as $idx => $s) {
            $posMap[$s->id] = $idx + 1;
        }

        $pos1 = $gt1->position > 0 ? $gt1->position : ($posMap[$gt1->id] ?? 1);
        $pos2 = $gt2->position > 0 ? $gt2->position : ($posMap[$gt2->id] ?? 2);

        // If they were equal, ensure one is lower and one is higher
        if ($pos1 === $pos2) {
            $pos1 = min($posMap[$gt1->id] ?? 1, $posMap[$gt2->id] ?? 2);
            $pos2 = max($posMap[$gt1->id] ?? 1, $posMap[$gt2->id] ?? 2);
            if ($pos1 === $pos2) $pos2 = $pos1 + 1;
        }

        // Swap
        $gt1->position = $pos2;
        $gt2->position = $pos1;
        $gt1->save();
        $gt2->save();

        $t1Name = $gt1->team ? $gt1->team->team_name : 'Pasukan 1';
        $t2Name = $gt2->team ? $gt2->team->team_name : 'Pasukan 2';
        $this->js("alert('Kedudukan {$t1Name} dan {$t2Name} telah berjaya ditukar!');");
    }
};
?>

<div class="space-y-6 animate-slide-up">
    
    @php
        $gameLabel = match($gameType) {
            'isobot' => 'Isobot Soccer',
            'sky_soccer' => 'Drone Sky Soccer',
            'obstacle' => 'Drone Obstacle',
            default => 'Permainan'
        };
        $isObstacle = $gameType === 'obstacle';
    @endphp

    <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div class="flex items-center gap-4">
            <a href="{{ route('admin.groups.index') }}" class="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border border-base-200 text-base-content/50 hover:text-primary transition-colors">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            </a>
            <div>
                <h2 class="text-xl font-extrabold text-base-content">{{ __('Senarai') }} @if($isObstacle) {{ __('Laluan') }} @else {{ __('Kumpulan') }} @endif: {{ $category->name }} ({{ __($gameLabel) }})</h2>
                <p class="text-sm text-base-content/60 mt-0.5">{{ $this->groups->count() }} @if($isObstacle) {{ __('laluan') }} @else {{ __('kumpulan') }} @endif {{ __('dijana') }}</p>
            </div>
        </div>
        
        <div class="flex items-center gap-2 flex-wrap">
            {{-- Create New Group Button --}}
            <button wire:click="openCreateGroupModal" 
                    class="bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold py-2.5 px-4 rounded-xl transition-colors flex items-center gap-2 shadow-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                <span>{{ __('Cipta Kumpulan Baharu') }}</span>
            </button>

            {{-- Late Team Injection Button --}}
            @if($this->unassignedTeams->isNotEmpty() && $this->groups->isNotEmpty())
                <button wire:click="openAddLateTeamModal()" 
                        class="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold py-2.5 px-4 rounded-xl transition-colors flex items-center gap-2 shadow-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    <span>{{ __('Masukkan Pasukan Lewat') }}</span>
                    <span class="bg-white/20 text-white px-2 py-0.5 rounded-full text-xs font-black">{{ $this->unassignedTeams->count() }}</span>
                </button>
            @endif

            @if(!$isObstacle)
            <button wire:click="generateFixtures" 
                    wire:confirm="{{ __('Sistem akan menjana padanan Round-Robin untuk semua kumpulan dalam kategori ini. Teruskan?') }}"
                    wire:loading.attr="disabled"
                    class="bg-primary hover:bg-primary/90 text-white text-sm font-bold py-2.5 px-4 rounded-xl transition-colors flex items-center gap-2 shadow-sm">
                <span wire:loading.remove wire:target="generateFixtures" class="flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    {{ __('Jana Jadual Perlawanan') }}
                </span>
                <span wire:loading wire:target="generateFixtures">{{ __('Menjana...') }}</span>
            </button>
            @else
            <button wire:click="generateFixtures" 
                    wire:confirm="{{ __('Sistem akan menjana jadual giliran Larian (Time Trial) untuk laluan ini. Teruskan?') }}"
                    wire:loading.attr="disabled"
                    class="bg-amber-500 hover:bg-amber-600 text-white text-sm font-bold py-2.5 px-4 rounded-xl transition-colors flex items-center gap-2 shadow-sm">
                <span wire:loading.remove wire:target="generateFixtures" class="flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    {{ __('Jana Giliran Larian') }}
                </span>
                <span wire:loading wire:target="generateFixtures">{{ __('Menjana...') }}</span>
            </button>
            @endif

            <button wire:click="deleteFixtures" 
                    wire:confirm="{{ __('AMARAN: Anda pasti mahu memadam semua jadual perlawanan dan mengosongkan statistik kumpulan ini?') }}"
                    wire:loading.attr="disabled"
                    class="bg-white border-2 border-red-200 text-red-500 hover:bg-red-50 text-sm font-bold py-2.5 px-4 rounded-xl transition-colors flex items-center gap-2 shadow-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                {{ __('Padam Jadual') }}
            </button>
        </div>
    </div>

    @if($this->groups->isEmpty())
        <div class="bg-amber-50 border border-amber-200 rounded-2xl px-6 py-8 text-center text-amber-800">
            <svg class="w-12 h-12 mx-auto mb-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <h3 class="font-bold text-lg">{{ __('Tiada') }} @if($isObstacle) {{ __('Laluan') }} @else {{ __('Kumpulan') }} @endif</h3>
            <p class="text-sm mt-1">{{ __('Belum dijana untuk kategori ini. Sila kembali ke muka hadapan dan klik "Jana", atau klik "Cipta Kumpulan Baharu" di atas.') }}</p>
            <div class="flex justify-center gap-3 mt-4">
                <a href="{{ route('admin.groups.index') }}" class="inline-block bg-amber-500 text-white px-5 py-2 rounded-xl text-sm font-bold hover:bg-amber-600 transition-colors">{{ __('Kembali') }}</a>
                <button wire:click="openCreateGroupModal" class="inline-block bg-blue-600 text-white px-5 py-2 rounded-xl text-sm font-bold hover:bg-blue-700 transition-colors">+ {{ __('Cipta Kumpulan') }}</button>
            </div>
        </div>
    @else
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            @foreach($this->groups as $group)
                <div class="bg-white rounded-2xl border border-base-200 shadow-sm overflow-hidden flex flex-col">
                    <div class="bg-base-200/50 px-5 py-3 border-b border-base-200 flex flex-col gap-2">
                        <div class="flex justify-between items-center">
                            <h3 class="font-extrabold text-lg text-primary">{{ $group->group_name }}</h3>
                            <div class="flex items-center gap-1.5 flex-wrap">
                                <span class="text-xs font-bold bg-white px-2.5 py-1 rounded-full text-base-content/60 shadow-sm">{{ $group->groupTeams->count() }} {{ __('Pasukan') }}</span>
                                @if(!$isObstacle && $group->groupTeams->count() >= 2)
                                    <button wire:click="openPlayoffModal({{ $group->id }})" 
                                            class="text-xs font-bold text-amber-700 hover:text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                                            title="{{ __('Jana Perlawanan Penentuan (Play-off) untuk kumpulan ini') }}">
                                        ⚔️ {{ __('Play-off') }}
                                    </button>
                                @endif
                                @if($this->unassignedTeams->isNotEmpty())
                                    <button wire:click="openAddLateTeamModal({{ $group->id }})" 
                                            class="text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                                            title="{{ __('Masukkan Pasukan Lewat ke Kumpulan ini') }}">
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                                        + {{ __('Tambah') }}
                                    </button>
                                @endif
                                <button wire:click="deleteSingleGroup({{ $group->id }})"
                                        wire:confirm="{{ __('Anda pasti mahu memadam kumpulan') }} {{ $group->group_name }}? {{ __('Semua pasukan dalam kumpulan ini akan dipindahkan ke senarai belum diundi.') }}"
                                        class="text-xs text-red-400 hover:text-red-600 p-1 rounded-lg hover:bg-red-50 transition-colors"
                                        title="{{ __('Padam Kumpulan Ini') }}">
                                    <svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                </button>
                            </div>
                        </div>
                        <div class="flex items-center gap-2 mt-1">
                            <label class="text-[10px] font-bold text-base-content/40 uppercase tracking-widest shrink-0">{{ __('Lokasi / Padang:') }}</label>
                            @if($gameType === 'isobot')
                                <select wire:change="assignField({{ $group->id }}, $event.target.value)" 
                                        wire:loading.class="opacity-50"
                                        class="select select-bordered select-xs flex-1 bg-white focus:outline-none focus:border-primary text-xs font-semibold">
                                    <option value="">- {{ __('Belum Ditetapkan') }} -</option>
                                    @for($i=1; $i<=15; $i++)
                                        <option value="{{ $i }}" {{ $group->field_number == $i ? 'selected' : '' }}>{{ __('Padang') }} {{ $i }}</option>
                                    @endfor
                                </select>
                            @elseif($gameType === 'sky_soccer')
                                <span class="text-xs font-bold text-base-content bg-base-200 px-3 py-1 rounded-lg flex-1">{{ __('Arena Sky Soccer (Tetap)') }}</span>
                            @else
                                <span class="text-xs font-bold text-base-content bg-base-200 px-3 py-1 rounded-lg flex-1">{{ $group->group_name }} ({{ __('Laluan Khas') }})</span>
                            @endif
                        </div>
                        @if($group->matches->isEmpty() && $group->groupTeams->count() >= ($isObstacle ? 1 : 2))
                            <div class="mt-1 flex items-center justify-between bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1 text-xs">
                                <span class="text-amber-800 text-[11px] font-medium">⚠️ {{ __('Jadual belum dijana untuk kumpulan ini') }}</span>
                                <button wire:click="generateSingleGroupFixtures({{ $group->id }})" 
                                        class="text-[11px] font-bold text-primary hover:underline ml-2">
                                    {{ __('Jana Sekarang') }} &rarr;
                                </button>
                            </div>
                        @endif
                    </div>
                    
                    {{-- Tie Detection Banner --}}
                    @php $tiedPairs = $this->getTiedPairs($group); @endphp
                    @foreach($tiedPairs as $pair)
                        <div class="px-3.5 py-2.5 border-t border-b {{ $pair['resolved'] ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900' : 'bg-amber-50 border-amber-300 text-amber-900' }} flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
                            <div class="flex-1">
                                <div class="flex items-center gap-1.5 flex-wrap">
                                    @if($pair['resolved'])
                                        <span class="font-black bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-md text-[9px] uppercase tracking-wider">✓ Kedudukan Ditentukan</span>
                                    @else
                                        <span class="font-black bg-amber-200 text-amber-900 px-2 py-0.5 rounded-md text-[9px] uppercase tracking-wider animate-pulse">⚠️ Seri Sempurna (#{{ $pair['rank1'] }} &amp; #{{ $pair['rank2'] }})</span>
                                    @endif
                                    <span class="font-black text-xs">{{ $pair['team1']->team->team_name }}</span>
                                    <span class="text-base-content/40 font-bold">&amp;</span>
                                    <span class="font-black text-xs">{{ $pair['team2']->team->team_name }}</span>
                                </div>
                                <p class="text-[10px] text-base-content/60 mt-0.5">
                                    {{ $pair['team1']->points }} mata &middot; {{ $pair['team1']->won }}M &middot; {{ $pair['team1']->goals_for }} jaringan &middot; {{ $pair['team1']->goals_against }} bolos
                                </p>
                            </div>
                            <div class="flex items-center gap-1.5 shrink-0">
                                <button wire:click="openPlayoffModal({{ $group->id }}, {{ $pair['team1']->team_id }}, {{ $pair['team2']->team_id }})" 
                                        class="bg-amber-600 hover:bg-amber-700 text-white font-bold px-2.5 py-1 rounded-lg text-[11px] flex items-center gap-1 transition-colors shadow-xs">
                                    ⚔️ {{ __('Jana Play-off') }}
                                </button>
                                <button wire:click="swapTeamPosition({{ $pair['team1']->id }}, {{ $pair['team2']->id }})" 
                                        class="bg-white border border-amber-300 hover:bg-amber-100 text-amber-900 font-bold px-2.5 py-1 rounded-lg text-[11px] flex items-center gap-1 transition-colors shadow-xs"
                                        title="{{ __('Tukar kedudukan antara dua pasukan ini secara manual') }}">
                                    🔄 {{ __('Tukar Posisi') }}
                                </button>
                            </div>
                        </div>
                    @endforeach

                    <div class="flex-1 p-0">
                        @if($group->groupTeams->isEmpty())
                            <div class="p-6 text-center text-xs text-base-content/40 italic">
                                {{ __('Tiada pasukan dalam kumpulan ini.') }}
                                @if($this->unassignedTeams->isNotEmpty())
                                    <br><button wire:click="openAddLateTeamModal({{ $group->id }})" class="text-primary font-bold hover:underline mt-1">+ {{ __('Masukkan Pasukan') }}</button>
                                @endif
                            </div>
                        @else
                            <table class="w-full text-sm">
                                <thead class="bg-base-100 border-b border-base-200">
                                    <tr>
                                        <th class="text-left py-2 px-3 text-[10px] font-bold text-base-content/40 uppercase tracking-widest w-7">#</th>
                                        <th class="text-left py-2 px-3 text-[10px] font-bold text-base-content/40 uppercase tracking-widest">{{ __('Pasukan') }}</th>
                                        @if(!$isObstacle)
                                            <th class="text-center py-2 px-2 text-[10px] font-bold text-base-content/40 uppercase tracking-widest w-8" title="Menang">M</th>
                                            <th class="text-center py-2 px-2 text-[10px] font-bold text-base-content/40 uppercase tracking-widest w-9" title="Perbezaan Gol">+/-</th>
                                            <th class="text-center py-2 px-2 text-[10px] font-bold text-primary uppercase tracking-widest w-9" title="Mata">PT</th>
                                        @endif
                                        <th class="text-right py-2 px-3 text-[10px] font-bold text-base-content/40 uppercase tracking-widest w-10">{{ __('Tindakan') }}</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-base-100">
                                    @foreach(($isObstacle ? $group->groupTeams : $group->getStandings()) as $idx => $gt)
                                        <tr class="hover:bg-base-50 transition-colors group/row">
                                            <td class="py-2.5 px-3 text-xs font-bold {{ $idx < 2 && !$isObstacle ? 'text-primary font-black' : 'text-base-content/40' }}">{{ $idx + 1 }}</td>
                                            <td class="py-2.5 px-3">
                                                <div class="flex items-center gap-1.5 flex-wrap">
                                                    <p class="font-bold text-base-content leading-tight">{{ $gt->team->team_name }}</p>
                                                    @if(!$isObstacle)
                                                        @if($idx === 0)
                                                            <span class="text-[9px] font-black bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded">1st</span>
                                                        @elseif($idx === 1)
                                                            <span class="text-[9px] font-black bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded">2nd</span>
                                                        @endif
                                                    @endif
                                                </div>
                                                <p class="text-[10px] text-base-content/50 mt-0.5 leading-tight">🏫 {{ $gt->team->school_name }}</p>
                                            </td>
                                            @if(!$isObstacle)
                                                <td class="py-2.5 px-2 text-center text-xs font-semibold text-base-content/70">{{ $gt->won }}</td>
                                                <td class="py-2.5 px-2 text-center text-xs font-semibold {{ $gt->goal_difference > 0 ? 'text-emerald-600' : ($gt->goal_difference < 0 ? 'text-red-500' : 'text-base-content/40') }}">
                                                    {{ $gt->goal_difference > 0 ? '+' : '' }}{{ $gt->goal_difference }}
                                                </td>
                                                <td class="py-2.5 px-2 text-center text-xs font-black text-primary">{{ $gt->points }}</td>
                                            @endif
                                            <td class="py-2.5 px-3 text-right">
                                                <button wire:click="removeTeamFromGroup({{ $group->id }}, {{ $gt->team->id }})"
                                                        wire:confirm="{{ __('Anda pasti mahu mengeluarkan pasukan') }} {{ $gt->team->team_name }} {{ __('daripada') }} {{ $group->group_name }}?"
                                                        class="opacity-0 group-hover/row:opacity-100 text-red-400 hover:text-red-600 p-1 rounded-lg hover:bg-red-50 transition-all"
                                                        title="{{ __('Keluarkan Pasukan') }}">
                                                    <svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                                </button>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    @endif

    {{-- Create Group Modal --}}
    @if($showCreateGroupModal)
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-slide-up border border-base-200">
                <div class="p-6 border-b border-base-200 bg-base-50 flex justify-between items-center">
                    <div>
                        <h3 class="font-black text-xl text-base-content">➕ {{ __('Cipta Kumpulan Baharu') }}</h3>
                        <p class="text-xs text-base-content/50 mt-0.5">{{ __('Tambah kumpulan tambahan secara manual.') }}</p>
                    </div>
                    <button wire:click="closeCreateGroupModal" class="w-8 h-8 rounded-full bg-base-200 text-base-content/50 hover:text-base-content flex items-center justify-center font-bold">✕</button>
                </div>

                <div class="p-6 space-y-4">
                    <div class="space-y-1.5">
                        <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('Nama Kumpulan:') }}</label>
                        <input type="text" wire:model="newGroupName" placeholder="Contoh: Kumpulan C" class="input input-bordered w-full rounded-xl text-sm focus:border-primary" />
                        @error('newGroupName') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div class="space-y-1.5">
                        <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('Huruf / Kod Kumpulan:') }}</label>
                        <input type="text" wire:model="newGroupLetter" placeholder="Contoh: C" class="input input-bordered w-full rounded-xl text-sm focus:border-primary uppercase" />
                        @error('newGroupLetter') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div class="space-y-1.5">
                        <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('Lokasi / Padang:') }}</label>
                        @if($gameType === 'isobot')
                            <select wire:model="newGroupField" class="select select-bordered w-full rounded-xl text-sm focus:border-primary">
                                <option value="">- {{ __('Pilih Padang (Pilihan)') }} -</option>
                                @for($i=1; $i<=15; $i++)
                                    <option value="{{ $i }}">{{ __('Padang') }} {{ $i }}</option>
                                @endfor
                            </select>
                        @elseif($gameType === 'sky_soccer')
                            <input type="text" wire:model="newGroupField" readonly class="input input-bordered w-full rounded-xl text-sm bg-base-200" value="Arena Sky Soccer" />
                        @else
                            <input type="text" wire:model="newGroupField" placeholder="Contoh: Course 3" class="input input-bordered w-full rounded-xl text-sm focus:border-primary" />
                        @endif
                    </div>
                </div>

                <div class="p-4 border-t border-base-200 bg-base-50 flex justify-end gap-2">
                    <button wire:click="closeCreateGroupModal" class="px-5 py-2.5 bg-base-200 hover:bg-base-300 text-base-content font-bold rounded-xl transition-colors text-sm">
                        {{ __('Batal') }}
                    </button>
                    <button wire:click="createGroup" 
                            wire:loading.attr="disabled"
                            class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors text-sm flex items-center gap-2 shadow-sm">
                        <span wire:loading.remove wire:target="createGroup">{{ __('Cipta Kumpulan') }}</span>
                        <span wire:loading wire:target="createGroup">{{ __('Mencipta...') }}</span>
                    </button>
                </div>
            </div>
        </div>
    @endif

    {{-- Late Team Injection Modal --}}
    @if($showAddLateTeamModal)
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-slide-up border border-base-200">
                <div class="p-6 border-b border-base-200 bg-base-50 flex justify-between items-center">
                    <div>
                        <h3 class="font-black text-xl text-base-content">➕ {{ __('Masukkan Pasukan Lewat') }}</h3>
                        <p class="text-xs text-base-content/50 mt-0.5">{{ __('Suntik pasukan ke dalam kumpulan & jana perlawanan tambahan.') }}</p>
                    </div>
                    <button wire:click="closeAddLateTeamModal" class="w-8 h-8 rounded-full bg-base-200 text-base-content/50 hover:text-base-content flex items-center justify-center font-bold">✕</button>
                </div>

                <div class="p-6 space-y-5">
                    @if($this->unassignedTeams->isEmpty())
                        <div class="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-sm text-amber-800">
                            <p class="font-bold">{{ __('Tiada Pasukan Belum Diundi') }}</p>
                            <p class="text-xs mt-1">{{ __('Semua pasukan berdaftar bagi kategori ini telah dimasukkan ke dalam kumpulan.') }}</p>
                        </div>
                    @else
                        {{-- Select Late Team --}}
                        <div class="space-y-1.5">
                            <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('1. Pilih Pasukan Lewat:') }}</label>
                            <select wire:model.live="selectedLateTeamId" class="select select-bordered w-full rounded-xl text-sm focus:border-primary">
                                <option value="">-- {{ __('Sila Pilih Pasukan') }} --</option>
                                @foreach($this->unassignedTeams as $uTeam)
                                    <option value="{{ $uTeam->id }}">
                                        {{ $uTeam->team_name }} (🏫 {{ $uTeam->school_name }})
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        {{-- Select Target Group --}}
                        <div class="space-y-1.5">
                            <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('2. Pilih Kumpulan Sasaran:') }}</label>
                            <select wire:model.live="selectedTargetGroupId" class="select select-bordered w-full rounded-xl text-sm focus:border-primary">
                                <option value="">-- {{ __('Sila Pilih Kumpulan') }} --</option>
                                @foreach($this->groups as $grp)
                                    @php
                                        $isSameSchool = false;
                                        if ($selectedLateTeamId) {
                                             $lateTeam = $this->unassignedTeams->firstWhere('id', $selectedLateTeamId);
                                             if ($lateTeam) {
                                                 $isSameSchool = $grp->groupTeams->contains(fn($gt) => strtolower(trim($gt->team->school_name)) === strtolower(trim($lateTeam->school_name)));
                                             }
                                        }
                                    @endphp
                                    <option value="{{ $grp->id }}">
                                        {{ $grp->group_name }} ({{ $grp->groupTeams->count() }} {{ __('Pasukan') }}) {{ $isSameSchool ? '⚠️ [' . __('Konflik Sekolah Sama') . ']' : '' }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        @if($selectedLateTeamId && $selectedTargetGroupId)
                            @php
                                $targetGrp = $this->groups->firstWhere('id', $selectedTargetGroupId);
                                $lateTeamObj = $this->unassignedTeams->firstWhere('id', $selectedLateTeamId);
                                $hasSameSchool = $targetGrp && $lateTeamObj ? $targetGrp->groupTeams->contains(fn($gt) => strtolower(trim($gt->team->school_name)) === strtolower(trim($lateTeamObj->school_name))) : false;
                            @endphp

                            @if($hasSameSchool)
                                <div class="bg-red-50 border border-red-200 text-red-700 p-3.5 rounded-2xl text-xs flex items-start gap-2">
                                    <svg class="w-4 h-4 shrink-0 mt-0.5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                                    <span><strong>{{ __('Peringatan:') }}</strong> {{ $targetGrp->group_name }} {{ __('sudah mempunyai pasukan dari sekolah yang sama') }} (<strong>{{ $lateTeamObj->school_name }}</strong>). {{ __('Sebaiknya pilih kumpulan lain jika ada pilihan.') }}</span>
                                </div>
                            @else
                                <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-2xl text-xs flex items-start gap-2">
                                    <svg class="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                    <span><strong>{{ __('Sesuai!') }}</strong> {{ __('Tiada konflik sekolah dalam') }} {{ $targetGrp->group_name }}. {{ __('Pasukan akan dijadualkan menentang') }} {{ $targetGrp->groupTeams->count() }} {{ __('pasukan sedia ada tanpa memadam sebarang skor perlawanan lama.') }}</span>
                                </div>
                            @endif
                        @endif
                    @endif
                </div>

                <div class="p-4 border-t border-base-200 bg-base-50 flex justify-end gap-2">
                    <button wire:click="closeAddLateTeamModal" class="px-5 py-2.5 bg-base-200 hover:bg-base-300 text-base-content font-bold rounded-xl transition-colors text-sm">
                        {{ __('Batal') }}
                    </button>
                    @if($this->unassignedTeams->isNotEmpty())
                    <button wire:click="addLateTeam" 
                            wire:loading.attr="disabled"
                            {{ !$selectedLateTeamId || !$selectedTargetGroupId ? 'disabled' : '' }}
                            class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors text-sm flex items-center gap-2 shadow-sm disabled:opacity-50">
                        <span wire:loading.remove wire:target="addLateTeam">{{ __('Sahkan & Masukkan') }}</span>
                        <span wire:loading wire:target="addLateTeam">{{ __('Memproses...') }}</span>
                    </button>
                    @endif
                </div>
            </div>
        </div>
    @endif

    {{-- Play-off Match Creation Modal --}}
    @if($showPlayoffModal)
        @php
            $playoffGroup = \App\Models\Group::with('groupTeams.team')->find($playoffGroupId);
        @endphp
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-slide-up border border-base-200">
                <div class="p-6 border-b border-base-200 bg-gradient-to-r from-amber-50 to-orange-50 flex justify-between items-center">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center font-black text-lg shadow-md shadow-amber-500/30">
                            ⚔️
                        </div>
                        <div>
                            <h3 class="font-black text-lg text-base-content">{{ __('Perlawanan Penentuan (Play-off)') }}</h3>
                            <p class="text-xs text-base-content/60">{{ $playoffGroup ? $playoffGroup->group_name : '' }} &middot; {{ $category->name }}</p>
                        </div>
                    </div>
                    <button wire:click="closePlayoffModal" class="w-8 h-8 rounded-full bg-base-200 text-base-content/50 hover:text-base-content flex items-center justify-center font-bold">✕</button>
                </div>

                <div class="p-6 space-y-4">
                    <div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-xs text-blue-800 leading-relaxed">
                        ℹ️ <strong>{{ __('Perlawanan Penentuan:') }}</strong> {{ __('Perlawanan ini akan dijana ke Padang pilihan dan dihantar ke Field Dashboard pengadil. Pemenang perlawanan penentuan akan automatik diletakkan di atas pasukan yang kalah dalam kedudukan kumpulan tanpa merosakkan statistik gol liga.') }}
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1.5">
                            <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('Pasukan 1 (Home):') }}</label>
                            <select wire:model="playoffTeam1Id" class="select select-bordered w-full rounded-xl text-sm font-semibold bg-white focus:border-primary">
                                <option value="">-- {{ __('Pilih Pasukan') }} --</option>
                                @if($playoffGroup)
                                    @foreach($playoffGroup->groupTeams as $gt)
                                        <option value="{{ $gt->team_id }}">{{ $gt->team->team_name }}</option>
                                    @endforeach
                                @endif
                            </select>
                            @error('playoffTeam1Id') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
                        </div>

                        <div class="space-y-1.5">
                            <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('Pasukan 2 (Away):') }}</label>
                            <select wire:model="playoffTeam2Id" class="select select-bordered w-full rounded-xl text-sm font-semibold bg-white focus:border-primary">
                                <option value="">-- {{ __('Pilih Pasukan') }} --</option>
                                @if($playoffGroup)
                                    @foreach($playoffGroup->groupTeams as $gt)
                                        <option value="{{ $gt->team_id }}">{{ $gt->team->team_name }}</option>
                                    @endforeach
                                @endif
                            </select>
                            @error('playoffTeam2Id') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
                        </div>
                    </div>

                    <div class="space-y-1.5">
                        <label class="text-xs font-bold text-base-content uppercase tracking-wider">{{ __('Lokasi Padang:') }}</label>
                        <select wire:model="playoffFieldNumber" class="select select-bordered w-full rounded-xl text-sm font-semibold bg-white focus:border-primary">
                            <option value="">-- {{ __('Pilih Padang') }} --</option>
                            @for($i=1; $i<=15; $i++)
                                <option value="{{ $i }}">{{ __('Padang') }} {{ $i }}</option>
                            @endfor
                            <option value="Arena Sky Soccer">Arena Sky Soccer</option>
                        </select>
                    </div>
                </div>

                <div class="p-4 border-t border-base-200 bg-base-50 flex justify-end gap-2">
                    <button wire:click="closePlayoffModal" class="px-5 py-2.5 bg-base-200 hover:bg-base-300 text-base-content font-bold rounded-xl transition-colors text-sm">
                        {{ __('Batal') }}
                    </button>
                    <button wire:click="createPlayoffMatch" class="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl transition-colors text-sm flex items-center gap-2 shadow-sm">
                        ⚔️ {{ __('Cipta Perlawanan Penentuan') }}
                    </button>
                </div>
            </div>
        </div>
    @endif
</div>
